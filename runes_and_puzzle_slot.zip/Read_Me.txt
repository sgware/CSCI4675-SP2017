package contains all 4 runes, and 1 rune slot holder.
the rune slot holder can be copied 3 times.

drag and drop them into unity, one at a time.

they will appear in the "Objects" folder.